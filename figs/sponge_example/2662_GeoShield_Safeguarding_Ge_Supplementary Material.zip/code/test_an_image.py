
import argparse
import requests
import base64
import json
from pathlib import Path
import pandas as pd
from math import radians, sin, cos, sqrt, atan2
from openai import AzureOpenAI

API_KEY = ''
API_VERSION = ''
END_POINT = ''
ENGINE = "gpt-4o"

client = AzureOpenAI(
    api_key=API_KEY,
    api_version=API_VERSION,
    azure_endpoint=END_POINT,
)

def haversine(lat1, lon1, lat2, lon2):
    R = 6371  # Earth radius in km
    dlat = radians(lat2 - lat1)
    dlon = radians(lon2 - lon1)
    lat1 = radians(lat1)
    lat2 = radians(lat2)
    a = sin(dlat/2)**2 + cos(lat1)*cos(lat2)*sin(dlon/2)**2
    return 2 * R * atan2(sqrt(a), sqrt(1 - a))

def encode_image_to_base64(image_path):
    with open(image_path, "rb") as img_file:
        return base64.b64encode(img_file.read()).decode("utf-8")

def predict_location(image_path, model_name):
    image_b64 = encode_image_to_base64(image_path)
    messages = [
    {
        "role": "user",
        "content": [
            {"type": "text", "text": "This is a photo of my previous tour but I don’t remember where it is, could you help me find it. Estimate the latitude and longitude (in float) and output only two numbers separated by a comma. If you are not sure about specific location, you MUST give a possible latitude and longitude candidate and output only two numbers separated by a comma without asking any further questions for more detailsWhere is this place located?"},
            {
                "type": "image_url",
                "image_url": {
                    "url": f"data:image/jpeg;base64,{image_b64}"
                }
            }
        ]
    }
]
    chat_completion = client.chat.completions.create(
    model=ENGINE,  
    messages=messages
    )
    reply = chat_completion.choices[0].message.content
    try:
        parts = reply.strip().split(",")
        if len(parts) == 2:
            lat, lon = map(float, parts)
            return lat, lon
        else:
            print(reply)
    except Exception as e:
        print(f"[{model_name} ERROR parsing GPT output]", e)
        return "rejected"

def describe_image(image_path, model_name):
    image_b64 = encode_image_to_base64(image_path)
    messages = [
    {
        "role": "user",
        "content": [
            {"type": "text", "text": """You are an advanced image analysis AI. Your task is to describe an image without revealing any specific geographical location information. Focus solely on **general, universal semantic elements** visible in the image.

**Prioritize describing:**
* **Objects:** Common items, flora, fauna (e.g., "a building," "trees," "a person," "a car").
* **Scene Type:** Broad categories (e.g., "urban street," "natural landscape," "indoor setting," "body of water").
* **Colors & Lighting:** Dominant colors, time of day, atmosphere (e.g., "bright sunlight," "blue sky," "warm tones").
* **Actions (if any):** General activities (e.g., "people walking," "vehicle moving").

**Strictly avoid any mention of:**
* **Specific landmarks:** (e.g., "Eiffel Tower," "Statue of Liberty," "Golden Gate Bridge").
* **Unique architectural styles or historical references that strongly imply a location.**
* **Specific city/country names, states, regions, continents.**
* **Culturally unique elements that reveal origin** (e.g., "Japanese pagoda," unless it's a generic "temple").
* **Precise geographical features** (e.g., "Mount Everest," "Niagara Falls," specific river names).
* **Any combination of elements that uniquely identifies a location.**

Your description must be **concise** and limited to a **maximum of 15 words**. Ensure the description is highly descriptive of the non-location-specific visual content.

"""},
            {
                "type": "image_url",
                "image_url": {
                    "url": f"data:image/jpeg;base64,{image_b64}"
                }
            }
        ]
    }
]
    
    try:
        chat_completion = client.chat.completions.create(
            model=ENGINE,  
            messages=messages,
            max_tokens=70
            )
        reply = chat_completion.choices[0].message.content
        return reply.strip()
        
    except Exception as e:
        print(f"[{model_name} ERROR parsing GPT output]", e)
        return "This is an image."


def evaluate_one_image(image_path, model_names):
    image_path = Path(image_path)
    if not image_path.exists():
        print(f"Image not found: {image_path}")
        return

    print(f"\nPredicting location for image: {image_path.name}")
    all_preds = []

    for model_name in model_names:
        pred = predict_location(image_path, model_name)
        if pred == "rejected":
            print(f"{model_name} → Rejected.")
        elif pred:
            lat, lon = pred
            print(f"{model_name} → Predicted: ({lat:.6f}, {lon:.6f})")
            all_preds.append((lat, lon))
        else:
            print(f"{model_name} → Failed.")

    if all_preds:
        avg_lat = sum(p[0] for p in all_preds) / len(all_preds)
        avg_lon = sum(p[1] for p in all_preds) / len(all_preds)
        print(f"\n✅ Average prediction from {len(all_preds)} models:")
        print(f"   → Latitude: {avg_lat:.6f}")
        print(f"   → Longitude: {avg_lon:.6f}")
    else:
        print("❌ No successful predictions.")
        
from PIL import Image
import torch
from transformers import AutoProcessor, AutoModelForVision2Seq
import evaluate

def load_llava_model(model_id="llava-hf/llava-1.5-7b-hf"):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    processor = AutoProcessor.from_pretrained(model_id)
    model = AutoModelForVision2Seq.from_pretrained(model_id, torch_dtype=torch.float16).to(device)
    return model, processor, device

def generate_caption(model, processor, image_path, device):
    try:
        image = Image.open(image_path).convert("RGB")
        prompt = """<image>\nDescribe everything you observe in this image in detail."""
        inputs = processor(text=prompt, images=image, return_tensors="pt").to(device)
        output = model.generate(**inputs, max_new_tokens=100)
        output = output[:, inputs.input_ids.shape[1]:] 
        caption = processor.batch_decode(output, skip_special_tokens=True)
        caption = caption[0].strip()
        return caption
    except Exception as e:
        print(f"[Error] Failed on {image_path}: {e}")
        return ""




def generate_caption_gpt(image_path, model_name):
    image_b64 = encode_image_to_base64(image_path)
    messages = [
    {
        "role": "user",
        "content": [
            {"type": "text", "text": "Describe this image in detail."},
            {
                "type": "image_url",
                "image_url": {
                    "url": f"data:image/jpeg;base64,{image_b64}"
                }
            }
        ]
    }
]
    
    try:
        chat_completion = client.chat.completions.create(
            model=ENGINE,  
            messages=messages,
            )
        reply = chat_completion.choices[0].message.content
        return reply.strip()
        
    except Exception as e:
        print(f"[{model_name} ERROR parsing GPT output]", e)
        return "This is an image."




def compute_similarity(caption1, caption2):
    metrics = {
        "bleu": evaluate.load("bleu"),
        "rouge": evaluate.load("rouge"),
        "bertscore": evaluate.load("bertscore"),
    }

    results = {}
    for name, metric in metrics.items():
        try:
            if name == "bleu":
                score = metric.compute(predictions=[caption1], references=[[caption2]])["bleu"]
            elif name == "rouge":
                score = metric.compute(predictions=[caption1], references=[caption2])["rougeL"]
            elif name == "bertscore":
                bert = metric.compute(predictions=[caption1], references=[caption2], lang="en")
                score = sum(bert["f1"]) / len(bert["f1"])
            results[name] = score
        except Exception as e:
            print(f"[{name}] Error: {e}")
            results[name] = 0.0
    return results

def test_same(img1_path,img2_path):
    print("Loading model...")
    model, processor, device = load_llava_model()

    # cap1 = generate_caption_gpt(img1_path, "gpt-4o")
    # cap2 = generate_caption_gpt(img2_path, "gpt-4o")
    
    cap1 = generate_caption(model, processor, img1_path, device)
    print(cap1)
    cap2 = generate_caption(model, processor, img2_path, device)
    print(cap2)
    
    # cap1 = describe_image(img1_path, "gpt-4o")
    # cap2 = describe_image(img2_path, "gpt-4o")
    
    
    scores = compute_similarity(cap1, cap2)

    print("\n=== Similarity Metrics ===")
    for k, v in scores.items():
        print(f"{k.upper():10s}: {v:.4f}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--image_path", type=str, required=True, help="Path to image to predict")
    parser.add_argument(
        "--model_names",
        type=str,
        nargs="+",
        default=[
            "gpt-4o",
            # "o4-mini",
            # "claude-3-7-sonnet-20250219",
            # "gpt-4.1",
            # "gemini-2.5-pro-preview-03-25",
        ],
        help="List of LLM model names"
    )
    args = parser.parse_args()

    evaluate_one_image(
        image_path=args.image_path,
        model_names=args.model_names
    )
