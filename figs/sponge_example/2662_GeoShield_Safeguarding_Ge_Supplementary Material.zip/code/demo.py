import os
import json
import hashlib
import random
import torchvision.transforms as transforms
import numpy as np
import torch
import torchvision
from PIL import Image
import hydra
from omegaconf import DictConfig
import os
from config_schema import MainConfig
from functools import partial
from typing import List, Dict, Optional
from torch import nn
from pytorch_lightning import seed_everything
import wandb
from omegaconf import OmegaConf
from tqdm import tqdm
import torchvision.transforms as T
from torchvision.transforms import ColorJitter, ToPILImage, ToTensor
from test_an_image import evaluate_one_image,describe_image

from surrogates import (
    ClipB16FeatureExtractor,
    ClipL336FeatureExtractor,
    ClipB32FeatureExtractor,
    ClipLaionFeatureExtractor,
    EnsembleFeatureLoss,
    EnsembleFeatureExtractor,
)

from utils import hash_training_config, setup_wandb, ensure_dir
import os
os.environ["WANDB_MODE"] = "disabled"


# Mapping from backbone names to model classes
BACKBONE_MAP: Dict[str, type] = {
    "L336": ClipL336FeatureExtractor,
    "B16": ClipB16FeatureExtractor,
    "B32": ClipB32FeatureExtractor,
    "Laion": ClipLaionFeatureExtractor,
}

def load_bboxes(json_path):
    with open(json_path, 'r') as f:
        raw = json.load(f)
    out = {}
    for name, v in raw.items():
        out[name] = {
            'size': tuple(v['image_size']),            # (H, W)
            'boxes': [d['box'] for d in v['detections']]
        }
    return out

def bbox_to_mask(box, orig_hw, dst_res, device):
    h0, w0 = orig_hw
    x1, y1, x2, y2 = box
    sx, sy = dst_res / w0, dst_res / h0
    x1, x2 = int(x1 * sx), int(x2 * sx)
    y1, y2 = int(y1 * sy), int(y2 * sy)
    mask = torch.zeros(1, 1, dst_res, dst_res, device=device)
    mask[:, :, y1:y2+1, x1:x2+1] = 1
    return mask

bbox_dict = load_bboxes("/data/lxw/M-Attack/GroundingDINO/all_detections1.json")

def attack_image_multi_bbox(cfg, extractor, loss_fn, img_path, det_info):
    img_pil = Image.open(img_path).convert('RGB')
    img_tensor = transform_fn(img_pil).unsqueeze(0).to(cfg.model.device)  # [1,3,input_res,input_res]
    cum_delta  = torch.zeros_like(img_tensor)

    for box in det_info['boxes']:
        mask = bbox_to_mask(box, det_info['size'], cfg.model.input_res, cfg.model.device)
        src = (img_tensor + cum_delta).detach()
        adv = fgsm_attack_masked(cfg, extractor, loss_fn,
                                 src, img_tensor, mask)
        cum_delta = adv - img_tensor

    final_adv = (img_tensor + cum_delta).clamp(0, 255)
    return final_adv

class MaskCrop:
    def __init__(self, input_res: int):
        self.input_res = input_res

    def __call__(self, image: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
        """
        Args:
            image: [1, 3, H, W] 或 [3, H, W]
            mask:  [1, 1, H, W] 或 [1, H, W]，值为0或1

        Returns:
            cropped image resized to (3, input_res, input_res)
        """
        if image.dim() == 4:
            image = image[0]
        if mask.dim() == 4:
            mask = mask[0, 0]
        elif mask.dim() == 3:
            mask = mask[0]

        indices = torch.nonzero(mask, as_tuple=False)
        if indices.shape[0] == 0:
            raise ValueError("Mask is empty, nothing to crop.")

        y1, x1 = indices.min(dim=0)[0]
        y2, x2 = indices.max(dim=0)[0]

        cropped = image[:, y1:y2 + 1, x1:x2 + 1]
        return cropped
    


def random_blur(image_tgt):
    kernel_size = int(torch.randint(low=3, high=7, size=(1,)).item())  # 奇数
    if kernel_size % 2 == 0:
        kernel_size += 1
    sigma = torch.rand(1).item() * 2.0  # sigma in [0, 2]

    blur = T.GaussianBlur(kernel_size=kernel_size, sigma=sigma)
    return blur(image_tgt)

class RandomGaussianBlur(nn.Module):
    def __init__(self, radius_min=0.1, radius_max=2.0):
        super(RandomGaussianBlur, self).__init__()
        self.radius_min = radius_min
        self.radius_max = radius_max

    def forward(self, x):
        x = transforms.ToPILImage()(x)
        radius = random.uniform(self.radius_min, self.radius_max)
        return x.filter(ImageFilter.GaussianBlur(radius))


def get_models(cfg: MainConfig):
    if not cfg.model.ensemble and len(cfg.model.backbone) > 1:
        raise ValueError("When ensemble=False, only one backbone can be specified")

    models = []
    for backbone_name in cfg.model.backbone:
        if backbone_name not in BACKBONE_MAP:
            raise ValueError(
                f"Unknown backbone: {backbone_name}. Valid options are: {list(BACKBONE_MAP.keys())}"
            )
        model_class = BACKBONE_MAP[backbone_name]
        model = model_class().eval().to(cfg.model.device).requires_grad_(False)
        models.append(model)

    if cfg.model.ensemble:
        ensemble_extractor = EnsembleFeatureExtractor(models)
    else:
        ensemble_extractor = models[0]  # Use single model directly

    return ensemble_extractor, models


def get_ensemble_loss(cfg: MainConfig, models: List[nn.Module]):
    ensemble_loss = EnsembleFeatureLoss(models)
    return ensemble_loss


def set_environment(seed=2023):
    random.seed(seed)
    os.environ["PYTHONHASHSEED"] = str(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


# Transform PIL.Image to PyTorch Tensor
def to_tensor(pic):
    mode_to_nptype = {"I": np.int32, "I;16": np.int16, "F": np.float32}
    img = torch.from_numpy(
        np.array(pic, mode_to_nptype.get(pic.mode, np.uint8), copy=True)
    )
    img = img.view(pic.size[1], pic.size[0], len(pic.getbands()))
    img = img.permute((2, 0, 1)).contiguous()
    return img.to(dtype=torch.get_default_dtype())

def random_blur(image_tgt):
    kernel_size = int(torch.randint(low=5, high=9, size=(1,)).item())  # 奇数
    if kernel_size % 2 == 0:
        kernel_size += 1
    sigma = 10.0  # torch.rand(1).item() *

    blur = T.GaussianBlur(kernel_size=kernel_size, sigma=sigma)
    return blur(image_tgt)

from transformers import LlavaForConditionalGeneration, AutoProcessor
def load_llava_model(cfg,model_id="llava-hf/llava-1.5-7b-hf"):
    device = torch.device(cfg.model.device)
    model = LlavaForConditionalGeneration.from_pretrained(model_id, torch_dtype=torch.float16).to(device)
    processor = AutoProcessor.from_pretrained(model_id)
    return model, processor, device

def generate_caption(model, processor, image_path, device):
    try:
        image = Image.open(image_path).convert("RGB")
        prompt = """<image>\nDescribe the image concisely."""
        inputs = processor(text=prompt, images=image, return_tensors="pt").to(device)
        output = model.generate(**inputs, max_new_tokens=77)
        output = output[:, inputs.input_ids.shape[1]:] 
        caption = processor.batch_decode(output, skip_special_tokens=True)
        caption = caption[0].strip()
        return caption
    except Exception as e:
        print(f"[Error] Failed on {image_path}: {e}")
        return ""
    
# Dataset with image paths
from torch.utils.data import Dataset
class ImageFolderWithPaths(Dataset):
    def __init__(self, root, transform=None):
        self.paths = [os.path.join(root, fname) for fname in os.listdir(root) if fname.lower().endswith(('.png', '.jpg', '.jpeg'))]
        self.transform = transform

    def __len__(self):
        return len(self.paths)

    def __getitem__(self, idx):
        path = self.paths[idx]
        image = Image.open(path).convert('RGB')
        if self.transform:
            image = self.transform(image)
        label = 0  # 或 None
        return image, label, path

@hydra.main(version_base=None, config_path="config", config_name="ensemble_3models_untarget")
def main(cfg: MainConfig):
    set_environment()

    # Initialize wandb using shared utility
    setup_wandb(cfg, tags=["image_generation"])
    # Define metrics relationship for logging multiple images
    wandb.define_metric("epoch")
    wandb.define_metric("*", step_metric="epoch")

    ensemble_extractor, models = get_models(cfg)
    ensemble_loss = get_ensemble_loss(cfg, models)

    transform_fn = transforms.Compose(
        [
            transforms.Resize(
                cfg.model.input_res,
                interpolation=torchvision.transforms.InterpolationMode.BICUBIC,
            ),
            transforms.CenterCrop(cfg.model.input_res),
            transforms.Lambda(lambda img: img.convert("RGB")),
            transforms.Lambda(lambda img: to_tensor(img)),
        ]
    )

    clean_data = ImageFolderWithPaths(cfg.data.cle_data_path, transform=transform_fn)
    target_data = ImageFolderWithPaths(cfg.data.tgt_data_path, transform=transform_fn)

    data_loader_imagenet = torch.utils.data.DataLoader(
        clean_data, batch_size=cfg.data.batch_size, shuffle=False
    )
    data_loader_target = torch.utils.data.DataLoader(
        target_data, batch_size=cfg.data.batch_size, shuffle=False
    )

    print("Using source crop:", cfg.model.use_source_crop)
    print("Using target crop:", cfg.model.use_target_crop)

    source_crop = (
        transforms.RandomResizedCrop(cfg.model.input_res, scale=cfg.model.crop_scale)
        if cfg.model.use_source_crop
        else torch.nn.Identity()
    )
    target_crop = (
        transforms.RandomResizedCrop(cfg.model.input_res, scale=cfg.model.crop_scale)
        if cfg.model.use_target_crop
        else torch.nn.Identity()
    )
    
    llava_model, llava_processor, llava_device = load_llava_model(cfg)
    
    for i, ((image_org, _, path_org), (image_tgt, _, path_tgt)) in enumerate(
        zip(data_loader_imagenet, data_loader_target)
    ):
        if cfg.data.batch_size * (i + 1) > cfg.data.num_samples:
            break

        print(f"\nProcessing image {i+1}/{cfg.data.num_samples//cfg.data.batch_size}")

        attack_imgpair(
            cfg=cfg,
            ensemble_extractor=ensemble_extractor,
            ensemble_loss=ensemble_loss,
            source_crop=source_crop,
            img_index=i,
            image_org=image_org,
            path_org=path_org,
            image_tgt=image_tgt,
            target_crop=target_crop,
            llava_model=llava_model,
            llava_processor=llava_processor,
            llava_device=llava_device,
            
        )

    wandb.finish()


def attack_imgpair(
    cfg: MainConfig,
    ensemble_extractor: nn.Module,
    ensemble_loss: nn.Module,
    source_crop: Optional[transforms.RandomResizedCrop],
    target_crop: Optional[transforms.RandomResizedCrop],
    img_index: int,
    image_org: torch.Tensor,
    path_org: List[str],
    image_tgt: torch.Tensor,
    llava_model,
    llava_processor,
    llava_device,
):
    image_org, image_tgt = image_org.to(cfg.model.device), image_tgt.to(
        cfg.model.device
    )
    attack_type = cfg.attack
    attack_fn = {
        "fgsm": fgsm_attack_masked,
    }[attack_type]
    
    try:
        img_name = os.path.basename(path_org[0])
        img_size = bbox_dict[img_name]['size']
        boxes = bbox_dict[img_name]['boxes']
    except:
        print(f"[Error] No bounding boxes found for {img_name}. Skipping.")
        img_size = (image_org.shape[2], image_org.shape[3])  # (H, W)
        boxes = []

    areas = []
    probs = []
    boxes.append([0, 0, img_size[1], img_size[0]]) 
    

    for box in boxes:
        m = bbox_to_mask(box, img_size, cfg.model.input_res, cfg.model.device)
        areas.append(torch.sum(m).float())
    areas = torch.stack(areas)
    total_area = areas.sum() + 1e-8 
    
    for box in boxes:
        m = bbox_to_mask(box, img_size, cfg.model.input_res, cfg.model.device)
        probs.append(torch.sum(m).float()/total_area) 
    
    
    
    adv_image = attack_fn(
    cfg=cfg,
    ensemble_extractor=ensemble_extractor,
    ensemble_loss=ensemble_loss,
    source_crop=source_crop,
    target_crop=target_crop,
    img_index=img_index,
    image_org=image_org,
    image_tgt=image_tgt,
    boxes = boxes,
    image_size=img_size,
    probs=probs,
    llava_model=llava_model,
    llava_processor=llava_processor,
    llava_device=llava_device,
    
)
    # Get config hash for output directory
    config_hash = hash_training_config(cfg) + '+geolocal'
    print(config_hash)
    
    # Save images
    for path_idx in range(len(path_org)):
        folder, name = (
            os.path.basename(os.path.dirname(path_org[path_idx])),
            os.path.basename(path_org[path_idx]),
        )
        folder_to_save = os.path.join(cfg.data.output, "img", config_hash, folder)
        ensure_dir(folder_to_save)

        ext = os.path.splitext(name)[1].lower()
        if ext in [".jpeg", ".jpg", ".png"]:
            save_name = name
        else:
            save_name = name + ".png"

        save_path = os.path.join(folder_to_save, save_name)
        torchvision.utils.save_image(adv_image[path_idx], save_path)
            


def log_metrics(pbar, metrics, img_index, epoch=None):
    """
    Log metrics to progress bar and wandb.

    Args:
        pbar: tqdm progress bar to update
        metrics: Dictionary of metrics to log
        img_index: Index of the image (for wandb logging)
        epoch: Optional epoch number for logging
    """
    # Format metrics for progress bar
    pbar_metrics = {
        k: f"{v:.5f}" if "sim" in k else f"{v:.3f}" for k, v in metrics.items()
    }
    pbar.set_postfix(pbar_metrics)

    # Prepare wandb metrics with image index
    wandb_metrics = {f"img{img_index}_{k}": v for k, v in metrics.items()}
    if epoch is not None:
        wandb_metrics["epoch"] = epoch

    # Log to wandb
    wandb.log(wandb_metrics)


def fgsm_attack_masked(
    cfg: MainConfig,
    ensemble_extractor: nn.Module,
    ensemble_loss: nn.Module,
    source_crop: Optional[transforms.RandomResizedCrop],
    target_crop: Optional[transforms.RandomResizedCrop],
    img_index: int,
    image_org: torch.Tensor,
    image_tgt: torch.Tensor,
    boxes: List[str],
    image_size: int,
    probs: List[float],
    llava_model,
    llava_processor,
    llava_device,
):
    """
    Perform FGSM attack on the image to generate adversarial examples.

    Args:
        cfg: Configuration parameters
        ensemble_extractor: Ensemble feature extractor model
        ensemble_loss: Ensemble loss function
        source_crop: Optional transform for cropping source images
        target_crop: Optional transform for cropping target images
        i: Index of the image (for logging)
        image_org: Original source image tensor
        image_tgt: Target image tensor to match features with

    Returns:
        torch.Tensor: Generated adversarial image
    """
    # Initialize perturbation
    delta = torch.zeros_like(image_org, requires_grad=True)
    print(delta.shape)
    # Progress bar for optimization
    pbar = tqdm(range(cfg.optim.steps), desc=f"Attack progress")
    #jitter = ColorJitter(brightness=0.4, contrast=0.4, saturation=0.4, hue=0.1)
    mask_crop = MaskCrop(cfg.model.input_res)
    
    tmp_img_path = './demo/tmp_image_tgt.jpg'
    torchvision.utils.save_image(image_tgt[0]/255, tmp_img_path)
    description = describe_image(tmp_img_path, ["gpt-4o"]) # description = generate_caption(llava_model, llava_processor, tmp_img_path, llava_device)
    print(description)
    
    # Main optimization loop
    for epoch in pbar:
        loss = 0
        
        box = random.choices(boxes)[0] 
        mask = bbox_to_mask(box, image_size, cfg.model.input_res, cfg.model.device)

        with torch.no_grad(): 
            img_tgt = mask_crop(image_tgt,mask).unsqueeze(0)
            ensemble_loss.set_ground_truth(img_tgt)

        # # Forward pass
        adv_image = image_org + delta
        
        crop = transforms.RandomCrop(224)
        adv_image_mask = crop(adv_image)

        adv_image = source_crop(adv_image)
        
        adv_features = ensemble_extractor(adv_image)
        adv_features_mask = ensemble_extractor(adv_image_mask)

        # Calculate metrics
        metrics = {
            "max_delta": torch.max(torch.abs(delta)).item(),
            "mean_delta": torch.mean(torch.abs(delta)).item(),
        }

        global_sim = ensemble_loss(adv_features)
        local_sim = ensemble_loss(adv_features_mask)
        loss -= (global_sim+local_sim)
        
        # metrics["global_similarity"] = global_sim.item()
        

        # if cfg.model.use_source_crop:
        #     # If using source crop, calculate additional local similarity
        #     local_features = ensemble_extractor(local_cropped)
        #     local_sim = ensemble_loss(local_features)
        #     loss -= local_sim
        #     metrics["local_similarity"] = local_sim.item()
        # else:
        #     # Otherwise use global similarity as loss
            # loss -= global_sim
        
        ###################################################
        # with torch.no_grad():
        #     img_tgt = target_crop(image_org) 
        #     ensemble_loss.set_ground_truth(img_tgt)
        
        
        # if cfg.model.use_source_crop:
        #     # If using source crop, calculate additional local similarity
        #     local_cropped = source_crop(adv_image)
        #     local_features = ensemble_extractor(local_cropped)
        #     local_sim = ensemble_loss(local_features)
        #     loss -= local_sim
        
        ###################################################
        with torch.no_grad():
            img_tgt = target_crop(image_org) 
            ensemble_loss.set_ground_truth(img_tgt)
            
        # pos_loss = ensemble_loss(adv_features)
        
        # loss -= pos_loss
        
        # ###################################################
        with torch.no_grad(): 
            ensemble_loss.set_geotext_truth(description, cfg.model.device)
        
        text_loss = ensemble_loss.geo_loss(adv_features)
        text_local_loss = ensemble_loss.geo_loss(adv_features_mask)
        loss -= (text_loss+ text_local_loss)
        ###################################################
        

        grad = torch.autograd.grad(loss, delta, create_graph=False)[0]

        # Update delta using FGSM
        delta.data = torch.clamp(
            delta + cfg.optim.alpha * torch.sign(grad),
            min=-cfg.optim.epsilon,
            max=cfg.optim.epsilon,
        )
        
    # Create final adversarial image
    adv_image = image_org + delta
    adv_image = torch.clamp(adv_image / 255.0, 0.0, 1.0)

    # Log final perturbation metrics
    final_metrics = {
        "max_delta": torch.max(torch.abs(delta)).item(),
        "mean_delta": torch.mean(torch.abs(delta)).item(),
    }
    log_metrics(pbar, final_metrics, img_index)

    
    return adv_image



if __name__ == "__main__":
    main()
